API Reference
*************

.. automodule:: pupil_apriltags
    :members:
    :undoc-members:
    :show-inheritance:
