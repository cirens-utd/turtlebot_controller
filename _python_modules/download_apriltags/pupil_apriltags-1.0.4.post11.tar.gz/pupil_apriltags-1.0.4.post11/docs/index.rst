Welcome to the |project| documentation!
=======================================

.. include:: ../README.rst
   :start-line: 26
   :end-line: 34

.. toctree::
   :maxdepth: 1

   api
   history

You can find the `source code on Github <https://github.com/pupil-labs/apriltags>`__.

.. include:: ../README.rst
   :start-line: 35
   :end-line: 95

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
