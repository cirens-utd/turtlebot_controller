# apriltags-source

This fork is an auxiliary repository for [the pupil-labs apriltag repository](https://github.com/pupil-labs/apriltags). It is built automatically from the main repository's build pipeline.

For more information, see the base repository for this fork: https://github.com/AprilRobotics/apriltag
